var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var inArray = require('in-array');
var index1 = require('./routes/index');
var users = require('./routes/users');
var fs = require('fs');
var elasticlunr = require('elasticlunr')
var app = express();
var core = require('cores')
_ = require('lodash')
var hasValue = require('has-value');
// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');
// uncomment after placing your favicon in /public
//app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(function(req, res, next) {

    // Website you wish to allow to connect
    res.setHeader('Access-Control-Allow-Origin', 'http://localhost:4300');

    // Request methods you wish to allow
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');

    // Request headers you wish to allow
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');

    // Set to true if you need the website to include cookies in the requests sent
    // to the API (e.g. in case you use sessions)
    res.setHeader('Access-Control-Allow-Credentials', true);

    // Pass to next layer of middleware
    next();
});;
app.use('/public', express.static(path.join(__dirname + '/public')));

var tm = require('text-miner');
var fs = require('fs');
var fs1 = require('fs');
var doc_1 = fs.readFileSync('./removestopandstem.txt', "utf8");
var doc_2 = fs1.readFileSync('./public/node-dev1.txt', "utf8");
var doc_3 = fs1.readFileSync('./public/ck-10-problems.txt', "utf8");
var doc_4 = fs1.readFileSync('./public/computer-secuirty-in-real-word.txt', "utf8");
var doc_5 = fs1.readFileSync('./public/using nodejs to build application.txt', "utf8");
var doc_6 = fs1.readFileSync('./public/Trust in government’s social media service and citizen’s patronage behavior.txt', "utf8");
var doc_7 = fs1.readFileSync('./public/writingResearchPapers.txt', "utf8");
var doc_8 = fs1.readFileSync('./writingResearchPapers.txt.json', "utf8");

var result_inverted = [{
        "Keywords": "ieee",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "transact",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "servic",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "comput",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "january",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "februari",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "compens",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "runtim",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "formal",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "model",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "verif",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "use",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "eventb",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "refin",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "proof",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "base",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "method",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "guillaum",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "babin",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "yamin",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "aitameur",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "marc",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "pantel",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "abstracton",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "interest",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "abil",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "compos",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "order",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "build",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "power",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "complex",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "one",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "run",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "interoper",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "distribut",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "set",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "sever",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "languag",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "like",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "bpel",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "describ",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "propos",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "similar",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "usual",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "system",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "composit",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "exhibit",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "inappropri",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "behavior",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "presenc",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "failur",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "mechan",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "avail",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "express",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "recoveri",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "case",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "paper",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "address",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "problem",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "correct",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "design",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "present",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "novel",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "correctbyconstruct",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "approach",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "defin",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "repair",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "fail",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "aspect",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "also",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "function",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "introduct",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "invari",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "whose",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "persist",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "enforc",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "differ",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "scenario",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "mode",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "equival",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "degrad",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "upgrad",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "reli",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "illustr",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "studi",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "index",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "termsweb",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "preserv",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "import",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "increas",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "huge",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "amount",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "trigger",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "browser",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "applic",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "need",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "appear",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "thereaft",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "offer",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "emerg",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "program",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "paradigm",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "notat",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "bpmn",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "xpdl",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "featur",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "basic",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "andor",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "oper",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "embed",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "lead",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "therefor",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "equip",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "suspens",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "current",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "process",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "activ",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "transfer",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "execut",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "exampl",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "scope",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "anoth",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "error",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "detect",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "semant",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "given",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "inform",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "standard",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "lack",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "theoret",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "foundat",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "identifi",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "definit",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "iritinptenseeiht",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "universit",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "toulous",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "franc",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "email",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "guillaumebabiniritfr",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "marcpantelenseeihtfr",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "manuscript",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "receiv",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "revis",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "accept",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "juli",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "date",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "public",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "version",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "obtain",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "reprint",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "articl",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "pleas",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "send",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "reprintsieeeorg",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "refer",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "digit",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "object",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "inde",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "ensur",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "safeti",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "repres",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "major",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "concern",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "particular",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "left",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "guarante",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "check",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "would",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "help",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "handler",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "prove",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "analyz",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "promot",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "mathemat",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "point",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "view",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "limit",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "attent",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "paid",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "repar",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "advoc",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "handl",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "ground",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "correspond",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "live",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "properti",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "leadsto",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "three",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "structur",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "follow",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "next",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "section",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "give",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "overview",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "person",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "permit",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "republicationredistribut",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "requir",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "permiss",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "httpwwwiee",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "borrow",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "ecommerc",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "chosen",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "support",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "develop",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "specif",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "work",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "within",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "discuss",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "root",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "global",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "stepwis",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "methodolog",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "detail",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "final",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "conclus",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "conclud",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "research",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "direct",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "relat",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "drawn",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "commun",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "techniqu",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "mention",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "gener",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "tradit",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "workflow",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "state",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "categori",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "topic",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "author",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "pcalculu",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "show",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "simpl",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "whole",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "petri",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "net",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "encod",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "construct",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "classic",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "deadlock",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "termin",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "statetransit",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "compat",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "algebra",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "loto",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "cadp",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "checker",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "extens",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "abstract",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "mainli",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "data",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "avoid",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "number",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "explos",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "space",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "explor",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "consequ",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "thu",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "neglect",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "third",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "proofbas",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "exploit",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "machin",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "decomposit",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "previous",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "januaryfebruari",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "previou",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "clean",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "verifi",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "either",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "variou",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "kind",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "dynam",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "reconfigur",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "adapt",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "selfheal",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "introduc",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "monitor",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "occurr",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "condit",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "except",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "caus",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "outlin",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "whatev",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "achiev",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "word",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "surpris",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "provid",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "beyond",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "capabl",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "twofold",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "hand",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "close",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "deal",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "manner",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "match",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "bisimul",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "appropri",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "extend",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "consist",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "appli",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "valid",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "componentbas",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "modelcheck",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "time",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "seen",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "part",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "faulttoler",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "depend",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "rodrigu",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "membership",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "element",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "reliabl",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "storag",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "moreov",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "demonstr",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "effici",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "cooper",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "enabl",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "multiag",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "redund",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "discoveri",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "possibl",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "altern",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "evalu",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "probabilist",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "review",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "meet",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "autonom",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "selfadapt",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "selfconfigur",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "self",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "sequenc",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "purchas",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "product",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "configur",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "allow",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "automat",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "occur",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "chang",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "selfcorrect",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "compon",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "fault",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "note",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "nonfunct",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "claim",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "well",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "improv",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "recal",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "ad",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "fulfil",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "relev",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "integr",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "result",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "electron",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "commerc",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "consid",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "supplier",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "action",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "perform",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "user",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "hesh",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "select",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "cart",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "pay",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "total",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "money",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "invoic",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "deliv",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "logist",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "event",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "depict",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "transit",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "label",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "payment",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "deliveri",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "suppos",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "websit",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "step",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "parallel",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "fill",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "pursu",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "complet",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "must",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "contain",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "expect",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "main",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "shall",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "whether",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "singl",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "cartsthi",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "take",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "care",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "alreadi",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "restor",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "halt",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "recent",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "evolut",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "notion",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "precondit",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "postcondit",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "hoar",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "weakest",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "dijkstra",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "substitut",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "calculu",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "firstord",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "logic",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "theori",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "character",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "variabl",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "claus",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "evolv",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "thank",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "made",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "context",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "wherea",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "static",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "axiomat",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "name",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "uniqu",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "declar",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "enumer",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "type",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "constant",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "axiom",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "attribut",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "constraint",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "theorem",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "deduc",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "see",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "list",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "enrich",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "remain",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "true",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "glu",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "variant",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "natur",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "finit",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "strictli",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "make",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "smaller",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "everi",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "guard",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "bodi",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "initialis",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "affect",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "option",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "paramet",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "fire",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "nondeterminist",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "choic",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "modifi",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "beforeaft",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "predic",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "determinist",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "first",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "assign",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "valu",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "act",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "effect",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "relationship",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "content",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "undetermin",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "oblig",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "rule",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "associ",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "plugin",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "rodin",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "platform",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "charg",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "interact",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "prover",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "fig",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "denot",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "local",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "feasibl",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "purpos",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "numer",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "decreas",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "compar",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "atom",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "tracebas",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "interleav",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "licit",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "trace",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "respect",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "observ",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "decis",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "move",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "level",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "less",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "concret",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "skip",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "necessari",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "implement",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "candid",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "behav",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "eventbas",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "railway",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "gradual",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "built",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "increment",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "initi",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "facet",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "tool",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "precis",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "messag",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "variablesclaus",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "flow",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "throw",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "synchron",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "accordingli",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "sequenti",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "iter",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "loss",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "call",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "empti",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "second",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "high",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "control",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "parametr",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "absenc",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "invoc",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "freeness",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "reachabl",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "particularli",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "literatur",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "sinc",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "explicitli",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "becom",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "sketch",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "toward",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "meta",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "alway",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "later",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "concept",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "manipul",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "least",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "stock",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "cartesian",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "world",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "site",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "finiteproduct",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "finitesit",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "cardsit",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "invariantsclaus",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "invand",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "correctli",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "desir",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "rancart",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "central",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "arbitrarili",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "subset",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "mean",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "play",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "role",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "descript",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "suitabl",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "nondetermin",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "somecart",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "specifi",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "seqvari",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "readi",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "cardcart",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "simul",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "sens",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "begin",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "pproduct",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "ransomecart",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "cardsomecart",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "bill",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "statement",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "idea",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "accomplish",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "hold",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "rest",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "sourc",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "target",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "belong",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "class",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "criteria",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "good",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "qualiti",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "realiz",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "exist",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "link",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "violat",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "recov",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "satisfi",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "suffic",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "safe",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "much",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "enough",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "socal",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "horizont",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "manag",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "switch",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "assum",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "assert",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "stage",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "abl",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "answer",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "come",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "fact",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "vice",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "versa",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "four",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "situat",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "goal",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "cover",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "unknown",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "infer",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "realist",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "proce",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "accord",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "decompos",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "figur",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "statechart",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "dash",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "vertic",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "line",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "side",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "additem",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "loop",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "union",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "lost",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "collect",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "item",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "last",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "shown",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "add",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "additemnew",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "right",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "exact",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "remark",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "even",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "cold",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "start",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "versu",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "warm",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "wellknown",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "eras",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "reenter",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "input",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "updat",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "copi",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "although",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "pass",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "involv",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "remaind",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "repeat",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "librari",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "explicit",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "suspend",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "contribut",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "identif",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "richer",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "known",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "failurecompens",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "sitea",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "siteb",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "cartw",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "expresb",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "sion",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "split",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "carta",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "continu",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "seamlessli",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "without",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "lose",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "additemw",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "rancartw",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "fsite",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "itemg",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "selectionw",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "resourc",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "long",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "additemaw",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "additembw",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "rancarta",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "fsitea",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "cartb",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "fsiteb",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "failuremod",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "indic",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "partit",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "partitionfailur",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "fokg",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "fnokg",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "failurestatu",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "record",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "still",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "among",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "failurew",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "normal",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "compensatewsw",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "tabl",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "statist",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "turn",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "acarta",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "acartw",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "acartb",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "experi",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "conduct",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "entir",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "loos",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "origin",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "compensatewswsdeg",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "alost",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "acart",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "compensatewswsupg",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "anew",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "includ",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "regard",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "flight",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "ticket",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "book",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "hotel",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "room",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "rental",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "futur",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "succeed",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "inputoutput",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "littl",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "focus",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "establish",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "coupl",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "orchestr",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "open",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "carri",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "could",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "reaction",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "busi",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "onlin",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "httpwwwomgorgspec",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "wmcw",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "interfacexml",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "wfmctc",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "oasi",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "wsbpel",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "httpbpel",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "xmlorg",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "beek",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "bucchiaron",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "gnesi",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "industri",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "proc",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "conf",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "internet",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "appl",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "abrial",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "softwar",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "engin",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "cambridg",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "univ",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "press",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "lucchi",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "mazzara",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "picalculu",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "aalst",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "mooij",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "stahl",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "wolf",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "pattern",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "analysi",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "intern",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "school",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "berlin",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "germani",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "springer",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "lohmann",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "massuth",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "weinberg",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "flexibl",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "knowl",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "hinz",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "schmidt",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "transform",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "foster",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "uchitel",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "mage",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "kramer",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "ltsaw",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "modelbas",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "choreographi",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "softw",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "nakajima",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "zhao",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "marconi",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "pistor",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "synthesi",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "sala",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "bordeaux",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "schaerf",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "reason",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "ferrara",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "orient",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "orger",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "thalheim",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "asmbas",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "mach",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "aitsadoun",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "syst",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "aci",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "bryan",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "critic",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "largescal",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "knowledgecent",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "hameurlain",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "wagner",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "liddl",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "schew",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "zhou",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "abouzaid",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "mullin",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "qamar",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "intel",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "technol",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "lanes",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "zavattaro",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "decid",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "instal",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "coordin",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "montesi",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "guidi",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "serviceori",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "joli",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "bouguettaya",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "sheng",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "daniel",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "ehrig",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "ermel",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "rung",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "pelliccion",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "fundam",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "bhattacharyya",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "dissert",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "newcastl",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "upon",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "tyne",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "palma",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "laumay",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "bellissard",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "workshop",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "componentori",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "ecoop",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "lanoix",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "dormoy",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "kouchnarenko",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "combin",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "architectur",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "lemo",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "castro",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "guerra",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "rubira",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "lopatkin",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "romanovski",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "rigor",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "corefin",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "tech",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "liskov",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "chen",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "schultz",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "tran",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "secur",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "pereverzeva",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "troubitsyna",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "laibini",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "toler",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "dseventb",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "refinementbas",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "computbas",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "tarasyuk",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "latvala",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "nummila",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "assess",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "onboard",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "satellit",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "ortmeier",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "parashar",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "hariri",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "unconvent",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "banar",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "fradet",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "giavitto",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "michel",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "discret",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "controlbas",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "technolog",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "natarajan",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "barua",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "patra",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "weyn",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "iftikhar",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "iglesia",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "ahmad",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "survey",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "gies",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "uller",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "shaw",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "roadmap",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "filieri",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "ghezzi",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "tamburrelli",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "assur",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "potena",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "optim",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "plan",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "cost",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "tradeoff",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "mirandola",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "scandurra",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "bbook",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "basi",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "disciplin",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "upper",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "saddl",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "river",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "prentic",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "hall",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "jastram",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "handbook",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "httphandbooke",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "hallersted",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "instanti",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "fundamenta",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "informatica",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "prinz",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "buchberg",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "trustworthi",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "cyberphys",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "ishikawa",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "london",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "chapman",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "hallcrc",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "symp",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "milner",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "concurr",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "prenticehal",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "harel",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "visual",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "unifi",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "master",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "degre",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "scienc",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "inptenseeiht",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "univers",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "safetycrit",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "professor",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "institut",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "nation",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "polytechniqu",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "inpt",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "enseeiht",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "member",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "acadi",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "team",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "irit",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "heart",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "ontolog",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "httpyaminepersoenseeihtfr",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "polytechni",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "driven",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "httppantelpersoenseeihtfr",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "republic",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "permie",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "ikram",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "hello",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "hey",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "hasan",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": 123,
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "sajid",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "sajidsoftwar",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "requir",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "specif",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "releas",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "inform",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "project",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "mytiangeph",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "intern",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "number",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "version",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "attach",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "worksheet",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "relat",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "document",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "introduct",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "onlin",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "buy",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "sell",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "becom",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "trend",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "today",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "modern",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "made",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "possibl",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "internet",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "anyth",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "want",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "avail",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "product",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "like",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "food",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "cloth",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "accessori",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "automobil",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "even",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "real",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "estat",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "promot",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "sold",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "provid",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "advantag",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "user",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "exposur",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "wide",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "rang",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "viewer",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "teen",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "adult",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "anyon",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "access",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "custom",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "anoth",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "make",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "process",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "much",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "simpler",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "search",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "easier",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "buyer",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "better",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "manag",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "seller",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "usual",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "approach",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "post",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "advertis",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "regard",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "easi",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "locat",
        "frequency": 2,
        "PostList": "2-3-",
        "": ""
    },
    {
        "Keywords": "popular",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "websit",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "ayosditocom",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "tipidcomph",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "kind",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "setup",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "direct",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "simpl",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "though",
        "frequency": 2,
        "PostList": "2-3-",
        "": ""
    },
    {
        "Keywords": "limit",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "wherein",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "transact",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "moneyproduct",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "exchang",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "also",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "doesnt",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "fulli",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "maxim",
        "frequency": 2,
        "PostList": "2-3-",
        "": ""
    },
    {
        "Keywords": "capabl",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "mytianggecom",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "site",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "full",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "dualway",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "implement",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "auction",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "featur",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "productforproduct",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "swap",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "case",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "stakehold",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "summari",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "quick",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "come",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "across",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "page",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "prioriti",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "essenti",
        "frequency": 2,
        "PostList": "2-3-",
        "": ""
    },
    {
        "Keywords": "frequenc",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "often",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "main",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "success",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "scenario",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "visit",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "home",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "keyin",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "name",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "press",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "enter",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "click",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "button",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "submit",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "form",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "list",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "match",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "queri",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "item",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "choic",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "view",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "detail",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "without",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "account",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "still",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "need",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "regist",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "option",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "result",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "desir",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "contact",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "info",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "busi",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "free",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "member",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "identifi",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "usernam",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "email",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "last",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "first",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "password",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "twice",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "address",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "landlin",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "cellphon",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "check",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "confirm",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "link",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "login",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "profil",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "ad",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "menu",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "store",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "databas",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "retriev",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "load",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "request",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "fill",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "field",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "photo",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "shown",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "plu",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "latest",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "includ",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "system",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "allow",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "select",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "contain",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "open",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "set",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "minimum",
        "frequency": 2,
        "PostList": "2-3-",
        "": ""
    },
    {
        "Keywords": "durat",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "mail",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "invit",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "inauct",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "appear",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "messag",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "bid",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "sent",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "send",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "repli",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "best",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "bidder",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "close",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "room",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "note",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "question",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "differ",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "within",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "time",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "span",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "place",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "amount",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "know",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "whether",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "hand",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "start",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "revers",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "mean",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "choos",
        "frequency": 2,
        "PostList": "2-3-",
        "": ""
    },
    {
        "Keywords": "offer",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "fillup",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "creat",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "wish",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "trade",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "trader",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "negoti",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "display",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "will",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "pictur",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "alreadi",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "crate",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "softwar",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "fillin",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "edit",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "save",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "function",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "effort",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "day",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "risk",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "safe",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "area",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "administr",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "descript",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "follow",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "step",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "formse",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "nonfunct",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "usabl",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "similar",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "interfac",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "ayosditoph",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "sulitcomph",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "ebayph",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "basic",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "typic",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "addit",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "easili",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "understand",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "especi",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "experienc",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "almost",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "content",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "part",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "avoid",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "confus",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "feel",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "continu",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "action",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "cannot",
        "frequency": 2,
        "PostList": "2-3-",
        "": ""
    },
    {
        "Keywords": "undon",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "layout",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "color",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "design",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "attract",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "give",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "activ",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "error",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "fail",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "attempt",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "recov",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "reliabl",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "must",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "abl",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "minor",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "well",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "seriou",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "establish",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "back",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "keep",
        "frequency": 2,
        "PostList": "2-3-",
        "": ""
    },
    {
        "Keywords": "track",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "done",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "encount",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "file",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "kept",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "backtrack",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "perviou",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "occur",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "warn",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "statu",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "secur",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "control",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "charact",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "long",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "ensur",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "human",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "comput",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "ask",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "solv",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "captcha",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "use",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "valid",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "verif",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "code",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "sure",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "realli",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "averag",
        "frequency": 2,
        "PostList": "2-3-",
        "": ""
    },
    {
        "Keywords": "encrypt",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "hour",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "except",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "mainten",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "announc",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "backup",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "log",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "preserv",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "data",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "prevent",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "broken",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "failur",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "perform",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "handl",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "least",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "condit",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "consid",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "constraint",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "connect",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "speed",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "browser",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "transfer",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "input",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "output",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "shouldnt",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "take",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "second",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "exampl",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "submiss",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "signup",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "less",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "minut",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "sampl",
        "frequency": 2,
        "PostList": "2-3-",
        "": ""
    },
    {
        "Keywords": "timescal",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "state",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "vari",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "maintain",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "anticip",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "sever",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "chang",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "trough",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "order",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "facilit",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "minim",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "effect",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "signific",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "applic",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "compli",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "standard",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "xhtml",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "transit",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "format",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "convent",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "definit",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "reconfigur",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "entiti",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "relationship",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "schema",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "support",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "suggest",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "improv",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "report",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "bug",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "help",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "develop",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "concern",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "portabl",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "client",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "side",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "window",
        "frequency": 2,
        "PostList": "2-3-",
        "": ""
    },
    {
        "Keywords": "linux",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "oper",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "mobil",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "phone",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "brows",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "host",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "problem",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "cross",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "platform",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "usag",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "clientsid",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "multipl",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "firefox",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "explor",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "safari",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "chrome",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "opera",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "properli",
        "frequency": 2,
        "PostList": "2-3-",
        "": ""
    },
    {
        "Keywords": "mysql",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "base",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "environment",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "commun",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "three",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "type",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "whole",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "signingup",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "particip",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "nonmemb",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "hisher",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "techniqu",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "hardwar",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "webbas",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "person",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "devic",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "server",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "compon",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "mainli",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "tool",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "html",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "javascript",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "jqueri",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "ajax",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "java",
        "frequency": 2,
        "PostList": "2-3-",
        "": ""
    },
    {
        "Keywords": "apach",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "protocol",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "hypertext",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "http",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "shall",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "sinc",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "reach",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "world",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "monitor",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "deploy",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "reboot",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "critic",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "updat",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "traffic",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "heavi",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "late",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "night",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "recoveri",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "measur",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "week",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "assumpt",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "depend",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "newer",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "ali",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "javed",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "abc",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "abcieee",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "transact",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "servic",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "comput",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "novemberdecemb",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "adapt",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "select",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "accord",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "densiti",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "multipl",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "aspect",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "jaehyun",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "hangyu",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "inyoung",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "member",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "ieee",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "abstractin",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "taskori",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "user",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "goal",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "model",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "repres",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "task",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "compos",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "activ",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "perform",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "access",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "instanc",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "local",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "environ",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "abstract",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "requir",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "specifi",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "resolv",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "bound",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "dynam",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "runtim",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "mani",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "candid",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "provid",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "similar",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "capabl",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "essenti",
        "frequency": 2,
        "PostList": "2-3-",
        "": ""
    },
    {
        "Keywords": "consid",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "qualiti",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "respons",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "time",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "latenc",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "avail",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "determin",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "find",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "composit",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "meet",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "optim",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "level",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "wellknown",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "nphard",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "problemth",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "complex",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "tasklevel",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "global",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "increas",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "exponenti",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "number",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "attribut",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "although",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "possibl",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "heurist",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "approach",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "show",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "reason",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "certain",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "strategi",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "often",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "fail",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "hard",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "constraint",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "need",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "paper",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "overcom",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "limit",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "propos",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "method",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "base",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "basic",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "idea",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "sampl",
        "frequency": 2,
        "PostList": "2-3-",
        "": ""
    },
    {
        "Keywords": "specif",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "qualityvalu",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "rang",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "divid",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "smaller",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "subrang",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "evalu",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "size",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "valu",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "calcul",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "util",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "highest",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "process",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "repeat",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "make",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "experi",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "result",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "effect",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "improv",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "success",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "rate",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "achiev",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "maintain",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "percent",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "comparison",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "exist",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "index",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "termsqual",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "introduct",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "recent",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "type",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "diversifi",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "includ",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "tradit",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "cloud",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "especi",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "associ",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "smart",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "devic",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "public",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "paradigm",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "known",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "internet",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "thing",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "wit",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "phone",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "robot",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "display",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "vehicl",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "functionallyequival",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "divers",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "henc",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "trivial",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "bind",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "appropri",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "framework",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "produc",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "variou",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "author",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "school",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "korea",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "advanc",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "institut",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "scienc",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "technolog",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "kaist",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "daejeon",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "south",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "email",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "skswhwo",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "kohangyu",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "ikokaistackr",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "manuscript",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "receiv",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "juli",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "revis",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "accept",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "date",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "current",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "version",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "inform",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "obtain",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "reprint",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "articl",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "pleas",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "send",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "reprintsieeeorg",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "refer",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "digit",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "object",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "identifi",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "order",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "togeth",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "coordin",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "structur",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "defin",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "sinc",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "expect",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "function",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "manner",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "check",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "weather",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "play",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "movi",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "altern",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "compon",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "exampl",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "attend",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "confer",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "decompos",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "sever",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "search",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "address",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "venu",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "combin",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "whole",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "flow",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "usual",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "case",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "googl",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "yahoo",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "differ",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "characterist",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "describ",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "cost",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "reliabl",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "critic",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "term",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "figur",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "distribut",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "four",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "person",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "permit",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "republic",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "permiss",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "httpwww",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "equival",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "dataset",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "contain",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "measur",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "use",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "commerci",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "benchmark",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "tool",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "highli",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "therefor",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "becom",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "harder",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "effici",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "larg",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "best",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "problem",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "hand",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "group",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "cannot",
        "frequency": 2,
        "PostList": "2-3-",
        "": ""
    },
    {
        "Keywords": "guarante",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "introduc",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "violat",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "individu",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "appli",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "better",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "solut",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "qosawar",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "nearoptim",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "major",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "httpwwwuoguelphcaqmahmoudqw",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "andor",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "increasess",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "set",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "decreas",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "dramat",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "caus",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "fact",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "satisfi",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "much",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "common",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "integr",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "indic",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "degre",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "less",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "reduc",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "regard",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "outperform",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "averag",
        "frequency": 2,
        "PostList": "2-3-",
        "": ""
    },
    {
        "Keywords": "close",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "remaind",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "organ",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "follow",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "next",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "section",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "work",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "explain",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "analyz",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "simul",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "demonstr",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "conclus",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "explan",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "futur",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "relat",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "earlier",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "wide",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "studi",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "classifi",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "three",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "gener",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "prefer",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "entir",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "addit",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "review",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "research",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "deal",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "iotbas",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "necessari",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "userdefin",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "weight",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "assign",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "aggreg",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "consider",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "word",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "even",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "howev",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "applic",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "depend",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "overal",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "simpli",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "carri",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "sometim",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "given",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "discuss",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "algorithm",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "commonli",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "integ",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "program",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "genet",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "transform",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "linear",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "outcom",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "maximum",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "profit",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "lowest",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "mathemat",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "whose",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "relationship",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "formula",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "purpos",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "score",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "maxim",
        "frequency": 2,
        "PostList": "2-3-",
        "": ""
    },
    {
        "Keywords": "scoresij",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "whether",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "instanti",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "notselect",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "ensur",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "qualityattribut",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "assum",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "true",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "qkij",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "constraintk",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "otherwis",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "compar",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "extens",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "rel",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "small",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "crucial",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "spontan",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "recurs",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "take",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "among",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "chosen",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "illustr",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "parallel",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "condit",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "loop",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "collaps",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "sequenti",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "sequenc",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "shown",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "popul",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "anoth",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "mutat",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "crossov",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "procedur",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "final",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "within",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "fix",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "amount",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "disadvantag",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "valid",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "random",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "iter",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "solv",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "short",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "call",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "wsheu",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "design",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "firstli",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "initi",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "replac",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "higher",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "significantli",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "scale",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "moreov",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "suitabl",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "start",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "preprocess",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "step",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "high",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "enumer",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "loem",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "minimum",
        "frequency": 2,
        "PostList": "2-3-",
        "": ""
    },
    {
        "Keywords": "rage",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "interv",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "newli",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "failur",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "alrifai",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "riss",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "mix",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "constraintsdecomposit",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "bold",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "circl",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "plot",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "axi",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "locat",
        "frequency": 2,
        "PostList": "2-3-",
        "": ""
    },
    {
        "Keywords": "star",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "suffer",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "heterogen",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "creat",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "difficult",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "effort",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "chen",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "requirementsdriven",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "selfoptim",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "estim",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "earn",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "busi",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "schedul",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "serviceori",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "explor",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "descript",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "layer",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "network",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "sens",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "main",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "resourc",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "issu",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "situat",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "analysi",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "perspect",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "also",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "pattern",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "second",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "practic",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "normal",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "get",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "narrow",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "likelihood",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "though",
        "frequency": 2,
        "PostList": "2-3-",
        "": ""
    },
    {
        "Keywords": "actual",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "shade",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "part",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "qosvalu",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "move",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "right",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "side",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "region",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "happen",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "understand",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "clearli",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "chang",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "ratio",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "allow",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "domain",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "implement",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "posit",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "occur",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "graph",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "rapidli",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "like",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "found",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "choic",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "first",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "investig",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "utilityvalu",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "tabl",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "choos",
        "frequency": 2,
        "PostList": "2-3-",
        "": ""
    },
    {
        "Keywords": "trend",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "contribut",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "xaxi",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "denot",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "sort",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "yaxi",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "seen",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "dottedlin",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "line",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "tend",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "nearbi",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "appear",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "summar",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "utilitydistribut",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "total",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "five",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "constrain",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "keep",
        "frequency": 2,
        "PostList": "2-3-",
        "": ""
    },
    {
        "Keywords": "around",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "might",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "mean",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "everi",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "lower",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "shift",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "toward",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "exclud",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "depict",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "phenomenon",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "shrunk",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "highervalu",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "statist",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "support",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "standard",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "deviat",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "dens",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "place",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "conclud",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "abl",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "harderqosconstrain",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "well",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "neartooptim",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "mixedinteg",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "except",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "examin",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "cope",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "phase",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "space",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "affect",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "previou",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "core",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "motiv",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "behind",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "properli",
        "frequency": 2,
        "PostList": "2-3-",
        "": ""
    },
    {
        "Keywords": "criteria",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "must",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "care",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "manag",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "probabl",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "vertic",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "bar",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "center",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "third",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "subsect",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "detail",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "instead",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "inspect",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "qosconstraint",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "accordingli",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "decomposit",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "consist",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "equal",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "denser",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "pivot",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "point",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "help",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "would",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "equat",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "aqvk",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "aqvkh",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "eqhk",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "aqvkj",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "previous",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "equals",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "drawback",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "broker",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "independ",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "boundari",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "filter",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "qmax",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "qmin",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "usij",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "exceed",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "constraintcheck",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "rule",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "boolean",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "alway",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "summari",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "conduct",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "seri",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "secondli",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "ad",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "nine",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "data",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "throughput",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "import",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "repositori",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "target",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "want",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "variant",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "factor",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "timeperform",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "vari",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "variat",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "static",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "baselin",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "densitybas",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "uniformli",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "across",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "last",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "alter",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "throughout",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "adjust",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "maxqkij",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "lpsolv",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "java",
        "frequency": 2,
        "PostList": "2-3-",
        "": ""
    },
    {
        "Keywords": "eclips",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "indigo",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "experiment",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "platform",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "run",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "window",
        "frequency": 2,
        "PostList": "2-3-",
        "": ""
    },
    {
        "Keywords": "intel",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "minqosconstraint",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "mention",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "versu",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "done",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "test",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "randomli",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "linearli",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "made",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "regardless",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "reflect",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "taken",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "contrast",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "slowli",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "rather",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "discov",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "uniqu",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "scalabl",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "threshold",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "basi",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "present",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "believ",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "mainli",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "correl",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "accur",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "spend",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "extend",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "branch",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "thread",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "threat",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "real",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "acknowledg",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "dualus",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "umrd",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "correspond",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "aggarw",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "verma",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "miller",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "milnor",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "driven",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "meteor",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "proc",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "conf",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "serv",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "almasri",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "mahmoud",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "world",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "ardagna",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "pernici",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "flexibl",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "tran",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "softwar",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "zhang",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "endtoend",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "atzori",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "iera",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "morabito",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "survey",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "telecommun",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "netw",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "berbner",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "spahn",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "repp",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "heckmann",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "steinmetz",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "canfora",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "penta",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "esposito",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "villani",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "evol",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "peng",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "feedback",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "control",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "janfeb",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "eyhab",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "qosbas",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "discoveri",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "rank",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "commun",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "huertacanepa",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "jimenezmolina",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "middlewar",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "pervas",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "aprjun",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "jaeger",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "rojecgoldmann",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "muhl",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "workflow",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "enterpris",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "distrib",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "urban",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "social",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "spatial",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "tempor",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "appl",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "artif",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "usercentr",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "ubiquit",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "techniqu",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "intellig",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "velasquez",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "jain",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "berlin",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "springerverlag",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "kwon",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "qualityofservic",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "orient",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "plan",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "architectur",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "syst",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "softw",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "jeon",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "jeong",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "park",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "technic",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "report",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "httpwwwwcorkrkrofficetr",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "wsqo",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "zhao",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "symp",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "liang",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "system",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "applicationlevel",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "servicesori",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "informat",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "nemhaus",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "wolsey",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "combinatori",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "york",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "wileyintersci",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "pising",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "knapsack",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "thesi",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "univ",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "copenhagen",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "denmark",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "dept",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "tang",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "sigecom",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "exch",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "silvacardoso",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "semant",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "georgia",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "athen",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "wang",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "vitvar",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "kerrigan",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "toma",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "zeng",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "benatallah",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "duma",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "kalagnanam",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "ajou",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "univers",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "interest",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "selfadapt",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "engin",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "secur",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "reconfigur",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "link",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "southern",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "california",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "professor",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "permise",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "librari",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "inform",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "scienc",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "research",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "content",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "list",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "avail",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "sciencedirect",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "humaninform",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "interact",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "develop",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "gari",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "marchionini",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "univers",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "north",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "carolina",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "chapel",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "hill",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "man",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "hall",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "continu",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "evolv",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "rapidli",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "digit",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "technolog",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "chang",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "natur",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "peopl",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "articl",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "argu",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "past",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "year",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "seen",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "shift",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "distinct",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "emphas",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "individu",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "specic",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "among",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "divers",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "form",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "amount",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "foci",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "aspect",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "work",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "blur",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "boundari",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "object",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "creat",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "discuss",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "compon",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "trend",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "challeng",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "surround",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "studi",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "present",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "elsevi",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "right",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "reserv",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "introduct",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "grow",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "import",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "servic",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "industri",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "media",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "assum",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "greater",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "role",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "educ",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "entertain",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "growth",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "practic",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "impact",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "reect",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "devot",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "discret",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "element",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "toward",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "ecolog",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "account",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "three",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "classic",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "book",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "physic",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "record",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "human",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "manag",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "mental",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "represent",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "captur",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "store",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "transmit",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "second",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "half",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "twentieth",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "centuri",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "away",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "acquisit",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "organ",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "collect",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "instead",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "began",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "independ",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "well",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "consid",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "relationship",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "commun",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "transfer",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "late",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "scholar",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "look",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "last",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "decad",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "pose",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "agenda",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "humancent",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "becam",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "userori",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "albeit",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "len",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "technic",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "access",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "exampl",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "report",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "summar",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "result",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "meet",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "establish",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "cuadra",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "associ",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "nine",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "twenti",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "project",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "categori",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "fell",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "user",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "born",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "eld",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "journal",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "explos",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "confer",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "retriev",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "humancomput",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "mani",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "chose",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "scientic",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "reductionist",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "approach",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "better",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "system",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "effort",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "use",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "search",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "engin",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "onlin",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "catalog",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "citat",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "index",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "virtual",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "refer",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "multimedia",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "uni",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "theori",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "design",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "also",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "inuenc",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "aim",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "transpar",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "allow",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "focu",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "problem",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "hand",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "weiser",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "calm",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "brown",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "primari",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "make",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "modern",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "depend",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "upon",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "coupl",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "close",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "quartercenturi",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "shneiderman",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "call",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "direct",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "manipul",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "understand",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "activ",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "directli",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "involv",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "control",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "increasingli",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "forc",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "take",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "help",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "phenomena",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "interdepend",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "output",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "emerg",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "event",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "thu",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "fundament",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "today",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "explain",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "state",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "statu",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "examin",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "integr",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "perspect",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "terminolog",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "caveat",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "email",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "address",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "marchilsuncedu",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "gener",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "term",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "artifact",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "admit",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "increas",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "rang",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "product",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "produc",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "machin",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "humanmachin",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "network",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "front",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "matter",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "doijlisr",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "part",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "informat",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "number",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "variat",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "centric",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "view",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "name",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "interest",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "profession",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "undertak",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "four",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "mean",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "articul",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "buckland",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "knowledg",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "head",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "thing",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "fourth",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "tempor",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "cyberspac",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "kind",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "particularli",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "sens",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "proection",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "self",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "consist",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "consciou",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "unconsci",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "reection",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "link",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "annot",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "includ",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "intellectu",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "real",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "world",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "follow",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "storag",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "format",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "usabl",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "express",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "visual",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "aural",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "tactil",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "histor",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "craft",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "mindbodi",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "onto",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "accord",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "cultur",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "signic",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "scheme",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "largescal",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "globallydistribut",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "instantan",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "relat",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "person",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "group",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "often",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "tool",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "case",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "medium",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "persist",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "consumpt",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "consum",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "experi",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "appli",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "possibl",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "transform",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "wellisch",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "trace",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "histori",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "economi",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "document",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "postworld",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "period",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "point",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "suggest",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "alon",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "school",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "faculti",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "engag",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "teach",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "much",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "broader",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "notion",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "even",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "move",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "extant",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "genesi",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "distribut",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "reus",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "preserv",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "deleg",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "broaden",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "social",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "polit",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "tendenc",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "accru",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "anoth",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "thought",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "creation",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "especi",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "schema",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "stimul",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "becom",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "faster",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "cycl",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "sever",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "way",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "stabl",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "grappl",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "dynam",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "morph",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "ultim",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "map",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "analog",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "signal",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "process",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "seeker",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "ration",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "cognit",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "actor",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "embodi",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "mind",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "cyber",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "issu",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "scale",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "layer",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "ident",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "instanti",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "prole",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "lter",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "spam",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "health",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "illustr",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "gure",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "figur",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "depict",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "informationcentr",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "center",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "variou",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "interactioncentr",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "stream",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "substrat",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "repres",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "cloud",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "affect",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "log",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "time",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "environ",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "requir",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "attend",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "mutual",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "thcenturi",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "bridg",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "concern",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "organiz",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "tradit",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "occupi",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "space",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "tangibl",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "bear",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "idea",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "rule",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "token",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "stand",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "aggreg",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "left",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "epistemolog",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "softwar",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "paint",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "music",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "score",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "video",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "data",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "academ",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "disciplin",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "publish",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "comput",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "tend",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "could",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "best",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "futur",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "critic",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "divid",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "label",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "procedur",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "assign",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "ad",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "authorit",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "identi",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "abstract",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "compress",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "gist",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "humanconsum",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "summari",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "match",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "need",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "curatori",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "protect",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "deterior",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "loss",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "root",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "static",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "text",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "base",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "except",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "somewhat",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "esoter",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "ubiqu",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "electron",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "shaken",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "foundat",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "characterist",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "wildli",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "fall",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "class",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "first",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "domin",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "textual",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "think",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "differ",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "continuum",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "level",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "code",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "decod",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "must",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "interpret",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "smoothli",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "extrem",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "statist",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "genet",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "sequenc",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "codeal",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "substanti",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "metadata",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "train",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "imag",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "immers",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "environmentsal",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "bound",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "lie",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "middl",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "pervas",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "oral",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "languag",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "imageri",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "sure",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "camera",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "telegraph",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "begun",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "dramat",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "balanc",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "abundantli",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "evid",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "varieti",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "exist",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "ubiquit",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "sprout",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "bud",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "player",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "satellit",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "internet",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "radio",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "clearli",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "stray",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "beyond",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "progress",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "howev",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "bodi",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "core",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "imageshar",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "flickr",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "hundr",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "million",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "televis",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "longer",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "tether",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "youtub",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "global",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "massiv",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "campr",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "blog",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "wiki",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "support",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "entir",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "obling",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "higher",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "enterpris",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "necessarili",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "young",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "demand",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "full",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "rather",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "augment",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "altern",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "advanc",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "easi",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "sound",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "scientist",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "discov",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "techniqu",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "factor",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "therefor",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "larg",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "manifest",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "inexpens",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "copi",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "without",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "easili",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "wellknown",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "properti",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "driven",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "movement",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "perfect",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "replic",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "cheap",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "mass",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "fact",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "potenti",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "encapsul",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "behavior",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "within",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "abil",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "hyperlink",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "intra",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "interobject",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "hypertext",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "hypermedia",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "adopt",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "wide",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "onetoon",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "bolter",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "analysi",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "implic",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "destin",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "across",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "anywher",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "implement",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "incorpor",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "unless",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "owner",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "edit",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "semiact",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "unidirect",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "jump",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "simpl",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "highli",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "constrain",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "power",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "lurk",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "behind",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "earli",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "model",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "type",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "stott",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "furuta",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "cabarru",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "trigg",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "zellweg",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "near",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "inher",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "contain",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "program",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "unitsfor",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "ifthen",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "condit",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "creatorconsum",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "spatial",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "extern",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "download",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "amazon",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "render",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "someon",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "street",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "appear",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "next",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "read",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "interim",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "whether",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "usag",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "licens",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "remain",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "valid",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "combin",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "programmat",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "open",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "current",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "autom",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "rank",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "ecommerc",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "recommend",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "featur",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "hint",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "central",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "placehold",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "region",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "page",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "onthey",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "common",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "leverag",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "order",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "custom",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "usercontrol",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "goal",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "agileview",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "framework",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "geisler",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "brunk",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "give",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "changeabl",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "display",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "mash",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "creativ",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "step",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "perform",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "artist",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "explor",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "audienc",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "particip",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "ephemer",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "paul",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "kaiser",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "loop",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "realtim",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "portrait",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "dancer",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "merc",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "cunningham",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "contribut",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "sourc",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "wonder",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "paramet",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "set",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "given",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "everi",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "uniqu",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "httpwwwopenendedgroupcomindexphpartworksloopspresentloopsecolog",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "miller",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "spooki",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "remix",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "written",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "practition",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "longstand",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "semant",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "concept",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "word",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "yield",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "promis",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "mayburi",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "synthesi",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "blake",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "pratt",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "ongo",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "introduc",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "handl",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "feed",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "click",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "sensor",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "determin",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "decid",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "context",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "offer",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "daunt",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "unleash",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "free",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "humankind",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "heavili",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "laden",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "scalabl",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "excit",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "urg",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "novelti",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "chao",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "perpetu",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "overload",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "unend",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "chain",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "novel",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "linkag",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "lead",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "exasper",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "dysfunct",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "come",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "comfort",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "closur",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "clear",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "demarc",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "end",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "standalon",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "acquir",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "reason",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "seek",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "taken",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "contemporan",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "psycholog",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "inuenti",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "midtwentieth",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "informationprocess",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "inspir",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "cybernet",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "ross",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "ashbi",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "norbert",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "wiener",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "devic",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "linguist",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "noam",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "chomski",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "georg",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "allen",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "newel",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "herbert",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "simon",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "posit",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "linear",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "strongli",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "limit",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "resourc",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "method",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "ask",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "aloud",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "solv",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "qualit",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "simul",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "problemsolv",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "although",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "success",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "solver",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "particular",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "rulebas",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "embed",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "expert",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "johnsonlaird",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "other",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "dene",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "plan",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "probe",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "conduct",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "presum",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "function",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "algorithm",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "observ",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "ofc",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "strength",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "popular",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "thinkaloud",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "parallel",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "known",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "predict",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "card",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "moran",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "usercent",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "evalu",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "quickli",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "econom",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "expand",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "februari",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "lisa",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "databas",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "return",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "paper",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "somewher",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "bibliograph",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "bate",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "belkin",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "oddi",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "brook",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "saracev",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "kantor",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "informationseek",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "sum",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "simpli",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "impli",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "focus",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "deliv",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "proper",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "queri",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "multipl",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "cours",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "larger",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "intersect",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "hcir",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "undergon",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "radic",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "depart",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "holist",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "situat",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "one",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "realm",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "vygotski",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "mediat",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "learn",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "start",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "western",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "discoveri",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "collin",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "duguid",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "hutchin",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "place",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "isol",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "descart",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "famou",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "phrase",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "begin",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "collabor",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "rhetor",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "major",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "recognit",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "live",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "clark",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "provid",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "empir",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "mammal",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "physiolog",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "johnson",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "appreci",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "treatis",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "shape",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "fidel",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "pejtersen",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "ingwersen",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "jrvelin",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "kuhlthau",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "play",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "attent",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "bibliometr",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "typic",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "solitari",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "unlimit",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "bruce",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "morri",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "horvitz",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "demonstr",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "driver",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "print",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "white",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "collar",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "profess",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "strong",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "constraint",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "necessit",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "separ",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "leav",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "fulltext",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "boolean",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "came",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "commerci",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "expect",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "salton",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "occurr",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "cooccurr",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "corpora",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "rais",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "addit",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "comparison",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "capac",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "price",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "rival",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "largest",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "expens",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "warehous",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "planet",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "essenc",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "cheaper",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "easier",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "everyth",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "select",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "dispos",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "draft",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "error",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "annoy",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "irrelev",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "enorm",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "reach",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "speed",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "utter",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "gestur",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "selfexpress",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "afford",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "merg",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "capabl",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "familiar",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "array",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "repeat",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "revis",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "share",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "made",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "done",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "highresolut",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "size",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "wallsiz",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "tini",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "screen",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "cell",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "phone",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "children",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "toy",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "leapster",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "portabl",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "headphon",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "convers",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "infrastructur",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "broad",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "enabl",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "contentshar",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "delici",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "ickr",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "like",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "myspac",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "facebook",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "memori",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "quantiti",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "bit",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "face",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "ltere",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "mine",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "corpus",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "incom",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "area",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "mainstream",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "intend",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "popul",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "regard",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "prosthet",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "workabl",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "difcult",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "enough",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "bloom",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "taxonomi",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "taylor",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "valuead",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "hierarchi",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "would",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "noumen",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "dissolv",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "long",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "synapt",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "less",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "public",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "librarian",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "identifi",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "life",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "execut",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "initi",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "student",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "special",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "action",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "entiti",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "reciproc",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "effect",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "character",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "necessari",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "specifi",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "amplitud",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "intens",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "frequenc",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "small",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "increment",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "epiphani",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "delet",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "slow",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "rapid",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "regular",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "chaotic",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "highinteract",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "high",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "rate",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "theoret",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "littl",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "feedback",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "turn",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "caus",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "literatur",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "someth",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "repetit",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "respons",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "mainli",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "onesid",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "claim",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "symmetr",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "drive",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "amorph",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "gross",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "oversimpl",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "neuron",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "doctrin",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "cajal",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "serv",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "metaphor",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "sometim",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "positron",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "emiss",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "tomographi",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "magnet",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "reson",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "fmri",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "slice",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "throughout",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "grasp",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "pet",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "huge",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "trivial",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "excus",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "alter",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "money",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "extens",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "seemingli",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "limitless",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "nonliv",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "seem",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "impoverish",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "noninteract",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "accept",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "inanim",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "built",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "affector",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "interactionfor",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "minut",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "ceas",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "intellig",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "build",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "highway",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "automobil",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "home",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "actual",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "indic",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "mitchel",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "explic",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "phenomenon",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "appendag",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "selv",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "appar",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "sinc",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "facilit",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "percept",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "intermediari",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "intermedi",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "sufcient",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "accomplish",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "foreign",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "intern",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "instant",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "connect",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "brain",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "impress",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "evolut",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "constantli",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "strengthen",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "dampen",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "ring",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "synaps",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "pattern",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "energi",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "dissip",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "stimuli",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "junction",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "higherlevel",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "mull",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "memor",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "reinstanti",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "neural",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "wherea",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "complex",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "similar",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "weak",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "wikipedia",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "propens",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "respond",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "phase",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "stabil",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "brainmind",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "ionic",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "spiritu",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "mindsoul",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "obtain",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "precis",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "ordinari",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "grace",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "act",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "strictli",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "akin",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "epigram",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "stone",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "tag",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "advertis",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "subscript",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "invit",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "least",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "reaction",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "ratelimit",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "bring",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "line",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "humanhuman",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "reev",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "nass",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "treat",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "spite",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "mammalian",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "react",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "humanlik",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "vari",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "session",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "mous",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "fraction",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "bottleneck",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "digest",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "facet",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "brows",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "interfac",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "mechan",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "abl",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "ebay",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "short",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "interv",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "bill",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "diagnosi",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "purpos",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "spink",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "jansen",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "pedersen",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "analys",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "infer",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "kelli",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "naturalist",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "instrument",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "laptop",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "clientsid",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "semest",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "basi",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "bilenko",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "cucerzan",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "might",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "geograph",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "statement",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "ajax",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "assembl",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "contextu",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "importantli",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "subtli",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "explicit",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "recent",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "track",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "subtl",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "searcher",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "modifi",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "skip",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "analyz",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "intention",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "nding",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "investig",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "quantit",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "indepth",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "ethnograph",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "daytoday",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "hous",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "expans",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "dvd",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "game",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "indentifi",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "materi",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "automat",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "harvest",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "bergmark",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "revolution",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "oclc",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "arisen",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "webbas",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "creator",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "freetext",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "webpag",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "seriou",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "solut",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "topic",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "descript",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "morvil",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "debat",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "basic",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "question",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "author",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "expertis",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "congress",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "bastion",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "vocabulari",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "hybrid",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "patron",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "cue",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "surrog",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "relev",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "assess",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "nontextu",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "endeavor",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "strategi",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "assist",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "curat",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "asset",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "httpwwwilsuncedu",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "vidarch",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "httpwwwlocgo",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "blue",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "ribbon",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "panel",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "envis",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "decentr",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "compact",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "audio",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "judg",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "watch",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "concurr",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "reliabl",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "deal",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "classifi",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "vision",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "bernersle",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "hendler",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "lassila",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "datamin",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "review",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "improv",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "good",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "supervis",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "cope",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "likewis",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "adapt",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "remot",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "lank",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "westbrook",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "nicholson",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "radford",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "silverstein",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "norm",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "chat",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "messag",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "channel",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "trial",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "answer",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "migrat",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "servicespec",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "tactic",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "questionansw",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "wise",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "monitor",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "final",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "referr",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "emphasi",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "specialist",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "laboratori",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "everywher",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "hardwar",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "cusumano",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "describ",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "corpor",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "chesbrough",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "spohrer",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "compani",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "businessori",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "upgrad",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "path",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "plethora",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "exhibit",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "trillion",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "consequ",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "conscious",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "signatur",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "leak",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "exoinform",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "togeth",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "promot",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "attract",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "intent",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "cite",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "embellish",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "comment",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "post",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "forward",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "awar",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "purchas",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "steal",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "ever",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "fulli",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "discern",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "valu",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "twentyrst",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "occur",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "commerc",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "snapshot",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "archiv",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "httparchiveorg",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "poster",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "searchabl",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "cost",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "equit",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "worldwid",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "crucial",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "structur",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "denit",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "advantag",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "unstructur",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "institut",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "know",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "ounder",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "repositori",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "optim",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "decemberjanuari",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "bulletin",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "asist",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "seri",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "trec",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "consider",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "underway",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "nonpubl",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "forum",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "httpwwwuliborg",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "allianc",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "googl",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "billion",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "glimps",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "largegroup",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "whole",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "information",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "people",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "technolog",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "timechang",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "intrins",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "transit",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "maintain",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "ownership",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "forese",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "recogn",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "conclus",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "titl",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "curriculum",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "thread",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "xerox",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "parc",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "tom",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "underli",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "architectur",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "scholtz",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "metric",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "satisfi",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "workshop",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "around",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "exploratori",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "respect",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "querydocu",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "implicit",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "singular",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "radioisotop",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "attach",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "killer",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "applic",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "plagiar",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "detect",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "washington",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "httpprojectsischoolwashingtoneduchii",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "informationthey",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "readviewlistenpond",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "extend",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "consumei",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "furthermor",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "matur",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "malleabl",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "condition",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "rstclass",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "randomli",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "anim",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "alongsid",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "acknowledg",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "thank",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "solomon",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "cassidi",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "sugimoto",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "editori",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "rachael",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "clemen",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "berrypick",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "background",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "proceed",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "acmieeec",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "joint",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "york",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "navig",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "tomorrow",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "what",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "go",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "youll",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "realli",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "want",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "american",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "medicin",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "societi",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "write",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "hillsdal",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "lawrenc",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "erlbaum",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "dumai",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "grudin",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "poltrock",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "behaviour",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "team",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "manifesto",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "put",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "cambridg",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "press",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "busi",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "march",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "http",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "informationrnetirpaperhtml",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "unpublish",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "doctor",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "dissert",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "wild",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "springerverlag",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "alta",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "vista",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "chicago",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "aesthet",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "harvard",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "measur",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "find",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "longitudin",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "compet",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "nealschuman",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "junejuli",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "kraft",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "annual",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "silver",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "spring",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "rhythm",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "cyborg",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "citi",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "searchtogeth",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "uist",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "ambient",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "ndabil",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "sebastapol",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "oreilli",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "englewood",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "cliff",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "prenticehal",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "educaus",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "pageidbhcp",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "equat",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "overlap",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "ieee",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "hyperdocu",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "automata",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "veric",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "tracebas",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "check",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "transact",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "textnet",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "networkbas",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "librarianship",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "enhanc",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "kraaij",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "vri",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "fuhr",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "kando",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "sigir",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "amsterdam",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "netherland",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "juli",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "script",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "httpwww",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "httpww",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "httpbooks",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "ieee",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "transact",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "servic",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "comput",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "mayjun",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "mobilityen",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "select",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "composit",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "shuiguang",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "deng",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "member",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "longtao",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "huang",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "dane",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "leon",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "zhao",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "zhaohui",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "senior",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "abstractmobil",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "busi",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "becom",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "realiti",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "ubiquit",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "internet",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "connect",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "popular",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "mobil",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "devic",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "wide",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "avail",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "cloud",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "howev",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "characterist",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "environ",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "unpredict",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "variat",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "network",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "signal",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "strength",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "present",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "challeng",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "optim",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "tradit",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "qosawar",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "method",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "individu",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "best",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "alway",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "result",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "constant",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "make",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "perform",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "invoc",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "locationbas",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "paper",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "discuss",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "problem",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "defin",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "formal",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "solv",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "research",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "propos",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "model",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "mobilityawar",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "rule",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "algorithm",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "teachinglearningbas",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "experiment",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "simul",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "demonstr",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "approach",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "obtain",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "better",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "solut",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "current",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "standard",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "nearoptim",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "nearli",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "linear",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "complex",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "respect",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "size",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "index",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "termsservic",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "introduct",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "develop",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "enabl",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "peopl",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "access",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "use",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "smart",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "address",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "anytim",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "anywher",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "increas",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "number",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "enterpris",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "will",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "provid",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "import",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "part",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "daili",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "live",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "recent",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "year",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "consumpt",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "deliveri",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "platform",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "mani",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "industri",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "govern",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "organ",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "worldwid",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "form",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "technolog",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "combin",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "million",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "download",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "around",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "world",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "gener",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "larg",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "yearli",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "revenu",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "offer",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "differ",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "field",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "continu",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "dramat",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "help",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "lifeenhanc",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "indispens",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "experi",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "modern",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "life",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "applic",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "aris",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "reliabl",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "respons",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "time",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "cost",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "discoveri",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "critic",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "specif",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "need",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "determin",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "colleg",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "scienc",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "zhejiang",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "univers",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "hangzhou",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "china",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "email",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "dengsg",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "wzhzjueducn",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "depart",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "informat",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "zurich",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "canton",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "switzerland",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "hdaninggmailcom",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "inform",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "system",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "citi",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "hong",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "kong",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "kowloon",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "jleonzhaogmailcom",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "manuscript",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "receiv",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "revis",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "sept",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "accept",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "date",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "public",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "version",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "june",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "reprint",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "articl",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "pleas",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "send",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "reprintsieeeorg",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "refer",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "digit",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "object",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "identifi",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "correct",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "among",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "thousand",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "qualiti",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "even",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "user",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "requir",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "complic",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "singl",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "bare",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "satisfi",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "compos",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "integr",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "sever",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "distribut",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "request",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "includ",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "multipl",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "task",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "function",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "thu",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "choos",
        "frequency": 2,
        "PostList": "2-3-",
        "": ""
    },
    {
        "Keywords": "claim",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "difficult",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "candid",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "consider",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "invok",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "context",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "locat",
        "frequency": 2,
        "PostList": "2-3-",
        "": ""
    },
    {
        "Keywords": "ident",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "profil",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "capabl",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "impact",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "place",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "move",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "websit",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "opensign",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "record",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "coverag",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "real",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "snapshot",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "shown",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "observ",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "base",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "station",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "uniform",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "vari",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "within",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "kilomet",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "therefor",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "intuit",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "would",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "focus",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "furthermor",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "execut",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "unexpect",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "lead",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "failur",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "necessari",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "adapt",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "mechan",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "httpopensignalcom",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "person",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "permit",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "republicationredistribut",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "permiss",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "exampl",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "improv",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "scalabl",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "conduct",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "seri",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "evalu",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "valid",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "global",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "approxim",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "much",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "compar",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "populationbas",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "remaind",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "follow",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "section",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "detail",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "illustr",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "motiv",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "introduc",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "definit",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "relat",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "describ",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "analysi",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "review",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "work",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "conclus",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "explor",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "possibl",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "futur",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "opensignalcom",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "focu",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "phase",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "later",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "consist",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "five",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "contribut",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "also",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "path",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "qomn",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "transmit",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "data",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "compon",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "specifi",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "allow",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "handl",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "structur",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "depend",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "util",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "tlbo",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "tailor",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "oper",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "scenario",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "dynam",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "notabl",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "outlin",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "assum",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "want",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "hotel",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "book",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "walk",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "stronger",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "averag",
        "frequency": 2,
        "PostList": "2-3-",
        "": ""
    },
    {
        "Keywords": "transmiss",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "rate",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "tom",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "cellphon",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "kbp",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "virtual",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "nonfunct",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "attribut",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "uddi",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "knowledg",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "directli",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "telecom",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "third",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "parti",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "monitor",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "acquir",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "suppos",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "find",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "ctrip",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "elong",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "wellknown",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "decis",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "confirm",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "wait",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "faster",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "start",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "handov",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "principl",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "cellular",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "switch",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "soon",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "get",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "area",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "lower",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "threshold",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "zero",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "simplif",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "final",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "finish",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "total",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "begin",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "next",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "establish",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "though",
        "frequency": 2,
        "PostList": "2-3-",
        "": ""
    },
    {
        "Keywords": "longer",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "henc",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "quit",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "essenti",
        "frequency": 2,
        "PostList": "2-3-",
        "": ""
    },
    {
        "Keywords": "take",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "arrang",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "travel",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "beij",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "know",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "weather",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "condit",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "flight",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "show",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "found",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "goe",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "subway",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "fastest",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "cannot",
        "frequency": 2,
        "PostList": "2-3-",
        "": ""
    },
    {
        "Keywords": "guarante",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "whole",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "consid",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "suboptim",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "reduc",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "issu",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "could",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "affect",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "prerequisit",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "give",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "clear",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "concept",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "scope",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "framework",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "adopt",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "extend",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "tripl",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "input",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "paramet",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "output",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "ntupl",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "denot",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "properti",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "throughput",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "spent",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "charg",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "gain",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "neg",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "rest",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "equival",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "volum",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "process",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "note",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "similarli",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "given",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "imag",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "file",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "exceed",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "must",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "larger",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "proper",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "plan",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "twotupl",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "implement",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "frti",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "repres",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "correspond",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "exist",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "achiev",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "three",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "step",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "first",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "build",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "abstract",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "unlik",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "concret",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "symbol",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "group",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "similar",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "interfac",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "togeth",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "control",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "statement",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "assign",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "loop",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "discov",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "suitabl",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "recommend",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "discoverrecommend",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "repositori",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "constraint",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "prefer",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "discoveryrecommend",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "replac",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "studi",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "compat",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "beyond",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "topic",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "interact",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "face",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "manag",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "latenc",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "inputoutput",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "span",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "point",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "map",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "motion",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "random",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "waypoint",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "usual",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "mainli",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "draw",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "twodimension",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "space",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "calcul",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "forecast",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "meanwhil",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "lastli",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "overlay",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "grid",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "cell",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "practic",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "situat",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "infinit",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "small",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "measur",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "cover",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "associ",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "valu",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "way",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "routin",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "applicationsservic",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "appl",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "histor",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "behavior",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "everi",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "chang",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "geograph",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "durat",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "speed",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "estim",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "altern",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "predict",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "wifi",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "instanc",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "node",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "associatedisassoci",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "track",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "particular",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "addit",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "volunt",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "report",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "incent",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "disclos",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "potenti",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "save",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "money",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "cooper",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "rout",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "forward",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "anoth",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "ad",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "question",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "maintain",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "suffici",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "firstli",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "abl",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "ideal",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "mqo",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "assumpt",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "remain",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "actual",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "obviou",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "limit",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "normal",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "complet",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "second",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "meter",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "reach",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "isnt",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "across",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "eas",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "mqoss",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "qomni",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "qomno",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "variabl",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "tabl",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "subject",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "mean",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "feasibl",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "vector",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "constrain",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "integ",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "deriv",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "llocat",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "equat",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "entir",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "gqo",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "local",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "sequenti",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "parallel",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "notat",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "mathemat",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "summat",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "product",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "maximum",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "minimum",
        "frequency": 2,
        "PostList": "2-3-",
        "": ""
    },
    {
        "Keywords": "simplic",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "onedimension",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "criteria",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "aggreg",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "overal",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "effici",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "dimens",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "belong",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "swarm",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "intellig",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "transform",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "smallest",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "qwith",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "theorem",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "relationship",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "proof",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "shortest",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "element",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "mqosui",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "target",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "program",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "famou",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "known",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "nondeterminist",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "polynomi",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "basic",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "overview",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "custom",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "like",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "natureinspir",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "popul",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "proceed",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "class",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "learner",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "moreov",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "analog",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "fit",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "techniqu",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "teacher",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "term",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "match",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "domain",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "grade",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "student",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "learn",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "initi",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "advantag",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "tune",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "decid",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "iter",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "randomli",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "xteacher",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "xnew",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "xold",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "rand",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "steplength",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "round",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "teach",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "factor",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "refinex",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "upper",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "bound",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "updat",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "leaner",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "accord",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "someth",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "keep",
        "frequency": 2,
        "PostList": "2-3-",
        "": ""
    },
    {
        "Keywords": "divers",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "avoid",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "converg",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "earli",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "good",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "analyz",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "refin",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "roundxj",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "flow",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "chart",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "updatethemselv",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "summar",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "main",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "teacherlearn",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "oipd",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "endfor",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "termin",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "otherwis",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "return",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "setup",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "machin",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "intel",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "core",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "python",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "memori",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "insert",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "creat",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "amount",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "depict",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "independ",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "unprejud",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "statist",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "necess",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "without",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "movement",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "mtime",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "signalstrength",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "gtime",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "lmtime",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "distanc",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "four",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "cosin",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "cosb",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "cycl",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "veloc",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "regularli",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "piecewis",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "period",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "randoma",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "comparison",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "xax",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "yax",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "shorter",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "close",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "outperform",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "indic",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "effect",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "whether",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "amplitud",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "adjust",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "rang",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "metric",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "improver",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "percent",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "regular",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "matter",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "posit",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "fluctuat",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "fix",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "frequenc",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "set",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "pass",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "certain",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "decreas",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "conclud",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "quickli",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "reason",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "notion",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "rel",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "surpass",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "caus",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "previou",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "reissu",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "less",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "perspect",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "investig",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "fundament",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "chose",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "genet",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "search",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "heurist",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "mimic",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "natur",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "cross",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "mutat",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "weight",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "particl",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "tri",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "regard",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "artifici",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "immun",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "inspir",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "theoret",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "immunolog",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "prove",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "high",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "plot",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "versu",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "outstand",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "least",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "other",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "runtim",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "ratio",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "regardless",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "slightli",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "choic",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "largescal",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "dataset",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "evolut",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "worst",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "nsabas",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "summari",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "tlbobas",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "wors",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "sacrific",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "add",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "although",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "littl",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "roughli",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "significantli",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "infeas",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "purpos",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "hand",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "scale",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "well",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "run",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "seem",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "fail",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "optimum",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "aspect",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "employ",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "serviceawar",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "multidimension",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "multichoic",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "knapsack",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "mmkp",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "zeng",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "still",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "appli",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "tsesmetzi",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "maxim",
        "frequency": 2,
        "PostList": "2-3-",
        "": ""
    },
    {
        "Keywords": "profit",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "wang",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "fuzzi",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "dissimilar",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "consum",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "decompositionbas",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "convers",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "decompos",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "penaltybas",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "decentr",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "code",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "partit",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "server",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "particip",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "endtoend",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "crossentropi",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "combinatori",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "strategi",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "enhanc",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "jiang",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "psobas",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "nonuniform",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "comprehens",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "built",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "hybrid",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "cultur",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "maxmin",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "foundat",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "recast",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "easi",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "flexibl",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "begun",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "fortuna",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "mohorc",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "wire",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "wireless",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "negoti",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "technic",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "carri",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "goal",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "toler",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "uncertain",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "author",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "probabl",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "character",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "seek",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "workflow",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "networkawar",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "featur",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "delay",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "nonnetwork",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "price",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "reput",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "success",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "formul",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "aim",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "energi",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "concern",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "relax",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "unknown",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "case",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "acknowledg",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "visit",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "scholar",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "thank",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "prof",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "stuart",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "madnick",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "valuabl",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "comment",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "suggest",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "support",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "nation",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "grant",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "hightech",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "badb",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "council",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "dinh",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "niyato",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "survey",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "architectur",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "commun",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "proc",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "telecommun",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "symp",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "topk",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "automat",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "tran",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "autom",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "tekinay",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "jabbari",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "channel",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "savsani",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "vakharia",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "novel",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "design",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "computaid",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "knowl",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "syst",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "haak",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "blau",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "hawaii",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "conf",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "xiong",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "dataintens",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "technol",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "karaenk",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "leukel",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "sugumaran",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "ontologybas",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "wirtschaftsinformatik",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "benatallah",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "duma",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "kalagnanam",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "middlewar",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "softw",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "social",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "networkbas",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "trust",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "expert",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "lecu",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "mehandjiev",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "semant",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "hilila",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "chibani",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "djouani",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "amirat",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "multidomain",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "serviceori",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "berlin",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "germani",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "springer",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "glover",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "link",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "grefenstett",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "intern",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "confer",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "east",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "sussex",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "unit",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "kingdom",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "psycholog",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "press",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "tang",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "congr",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "evol",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "zhou",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "bouguettaya",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "databas",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "advanc",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "yang",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "zhang",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "cristoforo",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "multipath",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "length",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "chromosom",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "clerc",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "york",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "wiley",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "skylin",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "fast",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "cloudbas",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "netw",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "kang",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "distrib",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "workshop",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "forum",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "multiobject",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "discret",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "slaawar",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "math",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "dasgupta",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "krishnakumar",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "wong",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "berri",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "aircraft",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "fault",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "detect",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "artif",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "xinchao",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "zichao",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "deploy",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "serv",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "sheng",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "driven",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "roussaki",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "syka",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "chao",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "chafl",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "chandra",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "mann",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "nanda",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "orchestr",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "poster",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "shen",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "chen",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "zhong",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "quick",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "qosdriven",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "dgqo",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "manuf",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "transport",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "exploit",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "janmar",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "multicriteria",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "trustbas",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "johnson",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "maltz",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "sourc",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "pawar",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "tomakoff",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "contextawar",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "pervas",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "gerla",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "milcom",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "centuri",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "calabres",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "lorenzo",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "ratti",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "human",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "collect",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "shenm",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "gametheoret",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "chadil",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "russameesawang",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "keeratiwintakorn",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "realtim",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "gpr",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "googl",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "earth",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "elect",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "engelectron",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "degre",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "professor",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "interest",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "softwar",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "engin",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "toward",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "assist",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "head",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "arizona",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "analyt",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "empir",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "insight",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "analys",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "variou",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "realworld",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "institut",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "agricultur",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "haa",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "school",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "berkeley",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "davi",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "chair",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "interim",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "eller",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "taught",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "previous",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "hkust",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "william",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "mari",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "elearn",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "suppli",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "chain",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "organiz",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "sinogermani",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "jointli",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "train",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "ieee",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "transact",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "servic",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "comput",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "mayjun",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "perform",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "costeffect",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "analys",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "cloud",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "base",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "reject",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "impati",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "user",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "yiju",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "chiang",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "student",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "member",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "yenchieh",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "ouyang",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "chinghsien",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "robert",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "senior",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "abstractcloud",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "innov",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "platform",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "offer",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "divers",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "resourc",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "infrastructur",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "softwar",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "howev",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "challeng",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "aspect",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "threat",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "directli",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "lead",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "numer",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "neg",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "impact",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "poor",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "throughput",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "unpredict",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "workload",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "wast",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "paper",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "problem",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "conduct",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "system",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "control",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "simultan",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "satisfi",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "guarante",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "first",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "studi",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "loss",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "analyz",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "accord",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "relat",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "factor",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "wait",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "buffer",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "size",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "cost",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "model",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "develop",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "address",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "performancescost",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "tradeoff",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "issu",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "balk",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "reneg",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "block",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "provis",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "taken",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "account",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "relationship",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "variat",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "multiserv",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "finit",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "demonstr",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "propos",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "polici",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "combin",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "heurist",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "algorithm",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "allow",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "provid",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "rate",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "within",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "solv",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "constrain",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "optim",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "simul",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "result",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "show",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "costsav",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "enhanc",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "verifi",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "compar",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "without",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "appli",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "index",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "termscost",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "probabl",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "introduct",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "loud",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "emerg",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "paradigm",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "elimin",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "burden",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "complex",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "manag",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "companiesus",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "util",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "pool",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "payasyougo",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "manner",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "instead",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "ownandus",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "pattern",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "suppli",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "sever",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "fundament",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "includ",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "iaa",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "paa",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "saa",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "exampl",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "amazon",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "elast",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "googl",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "engin",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "salesforc",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "exist",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "busi",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "datastorag",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "program",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "applic",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "respect",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "ondemand",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "reserv",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "instanc",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "leas",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "network",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "temporari",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "longterm",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "project",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "need",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "difficult",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "avoid",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "either",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "overprovis",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "underprovis",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "unpredictableseason",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "chang",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "gener",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "help",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "maintain",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "qualiti",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "scalabl",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "nevertheless",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "approach",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "depart",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "electr",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "nation",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "chunghs",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "univers",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "taichung",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "taiwan",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "email",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "yjchianggmailcom",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "ycouyangnchuedutw",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "scienc",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "inform",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "chung",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "hsinchu",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "chhchuedutw",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "manuscript",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "receiv",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "june",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "revis",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "accept",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "date",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "public",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "current",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "version",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "obtain",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "reprint",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "articl",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "pleas",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "send",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "reprintsieeeorg",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "refer",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "digit",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "object",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "identifi",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "mani",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "shortcom",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "follow",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "determin",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "best",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "peak",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "load",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "second",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "huge",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "energi",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "consumpt",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "requir",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "third",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "suffer",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "underutil",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "day",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "month",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "offseason",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "convers",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "conserv",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "oper",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "degrad",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "long",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "time",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "queu",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "length",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "high",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "abandon",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "immedi",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "experienc",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "intoler",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "latenc",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "furthermor",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "commonli",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "found",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "inevit",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "occur",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "environ",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "make",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "usersjob",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "attract",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "research",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "attent",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "balanc",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "bill",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "task",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "map",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "price",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "focu",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "shown",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "fig",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "mean",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "refus",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "join",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "queue",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "unlik",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "choos",
        "frequency": 2,
        "PostList": "2-3-",
        "": ""
    },
    {
        "Keywords": "face",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "would",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "accus",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "level",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "negoti",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "expect",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "abil",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "advanc",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "reach",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "consensu",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "content",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "sign",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "agreement",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "essenti",
        "frequency": 2,
        "PostList": "2-3-",
        "": ""
    },
    {
        "Keywords": "process",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "interest",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "parti",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "outlin",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "usag",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "oblig",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "therefor",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "penalti",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "compens",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "violat",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "contract",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "short",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "accur",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "analysi",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "serviceori",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "person",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "permit",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "permiss",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "discuss",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "effect",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "request",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "arriv",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "evalu",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "final",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "achiev",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "previous",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "dealt",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "profit",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "extend",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "take",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "main",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "contribut",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "summar",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "possibl",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "import",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "indic",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "design",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "consid",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "differ",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "potenti",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "experi",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "remaind",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "structur",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "section",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "give",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "brief",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "overview",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "finitebuff",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "describ",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "present",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "comparison",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "whole",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "work",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "futur",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "conclud",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "histori",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "review",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "telephon",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "patient",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "express",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "measur",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "averag",
        "frequency": 2,
        "PostList": "2-3-",
        "": ""
    },
    {
        "Keywords": "number",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "custom",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "could",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "term",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "joint",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "serv",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "also",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "mandelbaum",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "zeltyn",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "motiv",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "phenomenon",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "observ",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "call",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "data",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "center",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "clear",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "linear",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "aros",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "explor",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "framework",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "mmng",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "varieti",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "patienc",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "distribut",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "assumpt",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "converg",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "zero",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "asymptot",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "ratio",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "analyt",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "doran",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "interplay",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "variou",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "versu",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "delay",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "vari",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "processor",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "speed",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "ghosh",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "weerasingh",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "associ",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "singl",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "server",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "infinit",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "horizon",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "minim",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "explicit",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "strategi",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "limit",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "diffus",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "brownian",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "consist",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "thresholdtyp",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "feedbacktyp",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "drift",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "solut",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "use",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "construct",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "littl",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "mention",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "previou",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "mehdi",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "job",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "minimum",
        "frequency": 2,
        "PostList": "2-3-",
        "": ""
    },
    {
        "Keywords": "complet",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "schedul",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "rigor",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "ignor",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "consider",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "done",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "focus",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "capac",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "preliminari",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "fault",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "recoveri",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "submit",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "full",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "enter",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "otherwis",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "drop",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "failur",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "quantifi",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "respons",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "whose",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "densiti",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "function",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "deriv",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "khazaei",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "novel",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "approxim",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "farm",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "estim",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "point",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "accommod",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "heterogen",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "might",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "impos",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "longer",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "client",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "homogen",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "equival",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "behavior",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "hand",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "purpos",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "cappo",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "seattl",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "list",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "display",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "webpag",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "node",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "global",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "voronoi",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "diagram",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "devic",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "nearrealtim",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "shouraboura",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "bleher",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "virtual",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "supplement",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "commun",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "state",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "order",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "keep",
        "frequency": 2,
        "PostList": "2-3-",
        "": ""
    },
    {
        "Keywords": "world",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "appear",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "particip",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "share",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "placement",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "across",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "modul",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "highli",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "predict",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "mechan",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "facilit",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "collect",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "better",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "aim",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "fast",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "delaysensit",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "addit",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "costbenefit",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "selvarani",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "sadhasivam",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "group",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "alloc",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "taskgroup",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "avail",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "improv",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "computationcommun",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "particular",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "capabl",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "sent",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "costbas",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "leverag",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "market",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "theori",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "meet",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "lowest",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "assign",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "supplier",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "protocol",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "pure",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "java",
        "frequency": 2,
        "PostList": "2-3-",
        "": ""
    },
    {
        "Keywords": "threetier",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "hierarch",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "extens",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "architectur",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "maximum",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "flow",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "machin",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "hadji",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "zeghlach",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "dynam",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "multipl",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "tenant",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "demand",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "opportunist",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "select",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "appropri",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "physic",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "hwang",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "twophas",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "phase",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "mathemat",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "formula",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "amount",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "kalman",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "filter",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "adapt",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "subscrib",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "exploit",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "predictivebas",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "configur",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "knowledg",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "concern",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "descript",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "mmrk",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "detail",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "ident",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "sourc",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "poisson",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "exponenti",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "paramet",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "firstcomefirstserv",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "fcf",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "disciplin",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "adopt",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "repres",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "valu",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "denot",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "steadi",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "birthanddeath",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "happen",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "segment",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "defin",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "vector",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "normal",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "equat",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "steadyst",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "equal",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "alway",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "posit",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "higher",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "contrari",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "lessen",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "reduc",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "depict",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "sinc",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "simpli",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "compris",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "allevi",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "deal",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "wide",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "fact",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "front",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "stage",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "affect",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "subsequ",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "middl",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "deliv",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "expand",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "restrict",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "space",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "rule",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "usual",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "illustr",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "larger",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "decid",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "leav",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "plan",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "period",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "record",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "correspond",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "notat",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "tabl",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "divid",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "initi",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "histor",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "depend",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "calcul",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "multipli",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "togeth",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "type",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "cannot",
        "frequency": 2,
        "PostList": "2-3-",
        "": ""
    },
    {
        "Keywords": "retain",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "lack",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "waitingspac",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "hasnt",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "occupi",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "exclud",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "find",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "wellknown",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "item",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "written",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "similarli",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "henc",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "given",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "major",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "incur",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "quantiti",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "power",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "activ",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "subject",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "congest",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "forward",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "specif",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "overhead",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "releas",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "unit",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "prepar",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "startingup",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "hold",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "strongli",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "decis",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "variabl",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "appar",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "want",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "inadequ",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "perceiv",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "constraint",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "specifi",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "percent",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "threshold",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "contradictori",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "among",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "extrem",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "nonlinear",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "total",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "input",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "matrix",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "upper",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "bound",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "output",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "step",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "bring",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "begin",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "els",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "return",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "test",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "next",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "valid",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "gain",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "insight",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "assum",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "requestmin",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "made",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "three",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "matlab",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "increas",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "certainli",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "necessarili",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "seen",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "caus",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "highest",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "gap",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "becom",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "smaller",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "nearli",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "experiment",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "practic",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "mostli",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "rentpurchas",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "roughli",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "note",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "lower",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "reduct",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "remain",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "undetect",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "besid",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "tendenc",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "compli",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "natur",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "react",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "various",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "degre",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "individu",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "feel",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "satisfact",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "toler",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "influenc",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "actual",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "statist",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "randomli",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "chosen",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "case",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "balkingreneg",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "situat",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "impli",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "absolut",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "basi",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "sake",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "simplic",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "noncea",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "fix",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "less",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "former",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "tri",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "rel",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "stabl",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "significantli",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "origin",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "fail",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "captur",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "opportun",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "tackl",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "costsperform",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "realiz",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "traffic",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "popul",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "comprehens",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "conclus",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "success",
        "frequency": 3,
        "PostList": "2-3-4-",
        "": ""
    },
    {
        "Keywords": "necessit",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "sivathanu",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "yiduo",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "storag",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "proc",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "conf",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "zhang",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "secur",
        "frequency": 3,
        "PostList": "1-2-3-",
        "": ""
    },
    {
        "Keywords": "healthcar",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "wang",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "jiang",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "logist",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "method",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "monitor",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "contact",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "syst",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "mamat",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "ibrahim",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "symban",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "cooper",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "cardonha",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "assuncao",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "netto",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "cunha",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "queiroz",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "patienceawar",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "free",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "chain",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "boredom",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "mazzucco",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "dyachuk",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "setup",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "subramaniam",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "genet",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "keskin",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "taskin",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "hawaii",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "agentbas",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "transit",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "fourth",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "quarter",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "green",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "slaawar",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "supercomput",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "math",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "zhao",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "alfa",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "telecommun",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "empiricallydriven",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "spectrum",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "lipski",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "thompson",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "servicetim",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "netw",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "appl",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "heavi",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "stochast",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "yang",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "misic",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "mgmmr",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "tran",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "parallel",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "distrib",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "beschastnikh",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "krishnamurthi",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "anderson",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "educ",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "sigcs",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "bulletin",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "internet",
        "frequency": 4,
        "PostList": "1-2-3-4-",
        "": ""
    },
    {
        "Keywords": "chong",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "karuppiah",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "yassin",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "nazir",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "batcha",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "farcrest",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "euclidean",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "steiner",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "treebas",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "consum",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "intel",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "technol",
        "frequency": 1,
        "PostList": "1-",
        "": ""
    },
    {
        "Keywords": "chen",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "subscript",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "gross",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "shortl",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "harri",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "york",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "wiley",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "zheng",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "dong",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "social",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "attribut",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "armoni",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "maglara",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "callback",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "option",
        "frequency": 2,
        "PostList": "1-2-",
        "": ""
    },
    {
        "Keywords": "realtim",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "zipkin",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "onlin",
        "frequency": 3,
        "PostList": "1-2-4-",
        "": ""
    },
    {
        "Keywords": "httpawsamazoncomecpr",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "zeroloss",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "shao",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "annu",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "softw",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "workshop",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "nathuji",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "kansal",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "ghaffarkhah",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "qcloud",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "interfer",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "qosawar",
        "frequency": 1,
        "PostList": "3-",
        "": ""
    },
    {
        "Keywords": "calheiro",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "ranjan",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "buyya",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "toward",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "bsee",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "feng",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "chia",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "memphi",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "tennesse",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "faculti",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "hsing",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "august",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "professor",
        "frequency": 2,
        "PostList": "1-3-",
        "": ""
    },
    {
        "Keywords": "chair",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "nchu",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "hyperspectr",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "imag",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "medic",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "mobil",
        "frequency": 1,
        "PostList": "2-",
        "": ""
    },
    {
        "Keywords": "multimedia",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "distinguish",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "school",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "tianjin",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "technolog",
        "frequency": 3,
        "PostList": "1-3-4-",
        "": ""
    },
    {
        "Keywords": "china",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "highperform",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "publish",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "refere",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "journal",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "confer",
        "frequency": 2,
        "PostList": "3-4-",
        "": ""
    },
    {
        "Keywords": "proceed",
        "frequency": 1,
        "PostList": "4-",
        "": ""
    },
    {
        "Keywords": "book",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "chapter",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "area",
        "frequency": 2,
        "PostList": "2-4-",
        "": ""
    },
    {
        "Keywords": "involv",
        "frequency": 2,
        "PostList": "1-4-",
        "": ""
    },
    {
        "Keywords": "conferencesworkshop",
        "frequency": 0,
        "PostList": "",
        "": ""
    },
    {
        "Keywords": "committe",
        "frequency": 0,
        "PostList": "",
        "": ""
    }
];
app.get('/test', function(req, res) {

    console.log(doc_8)
    res.json(result_inverted)



})
app.get('/persons', function(req, res) {
    var filePath = "./public/researh_paper/"; // Or format the path using the `id` rest param
    var fileName = req.params.name + ".txt"; // The default name the browser will use

    res.download(filePath, fileName);
})
app.get('/download/file/:name', function(req, res, next) {
    var filePath = "./public/researh_paper/"; // Or format the path using the `id` rest param
    var fileName = req.params.name + ".txt"; // The default name the browser will use

    res.download(filePath, fileName);
});
app.get('/bolean/search/:text', function(req, res) {


})
app.use('/:qtext', function(req, res) {

    var index = elasticlunr(function() {
        this.addField('title');
        this.addField('body');
        this.setRef('id');
        this.saveDocument(false);
    });
    var doc1 = {
        "id": 1,
        "title": "Information system",
        "body": doc_1
    }

    var doc2 = {
        "id": 2,
        "title": "Computer interaction",
        "body": doc_2
    }
    var doc3 = {
        "id": 3,
        "title": "Computer secuirty",
        "body": doc_3
    }
    var doc4 = {
        "id": 4,
        "title": "Computer application using nodejs",
        "body": doc_4
    }
    var doc5 = {
        "id": 5,
        "title": "human computer interaction",
        "body": doc_5
    }
    var doc6 = {
        "id": 6,
        "title": "nodejs in large scale application",
        "body": doc_6
    }

    var doc7 = {
        "id": 7,
        "title": "trust in e govt",
        "body": doc_7
    }





    index.addDoc(doc1);
    index.addDoc(doc2);
    index.addDoc(doc3);
    index.addDoc(doc4);
    index.addDoc(doc5);
    index.addDoc(doc6);
    index.addDoc(doc7);
    elasticlunr.clearStopWords();
    ress = index.search(req.params.qtext)
    result_term = []
    _.forEach(ress, function(value, key) {

        if (key == 0) {
            result_term[0] = { url: "http://127.0.0.1:3000/public/node-dev.txt", title: "Information system", author: "adil", score: value.score }
        }
        if (key == 1) {
            result_term[1] = { url: "http://127.0.0.1:3000/public/node-dev.txt/node-dev1.txt", title: "computer interaction", author: "Ali", score: value.score }
        }
        if (key == 3) {
            result_term[3] = { url: "http://127.0.0.1:3000/public/Trust in government’s social media service and citizen’s patronage behavior.txt", title: "E govt", author: "Ali", score: value.score }
        }
        if (key == 4) {
            result_term[4] = { url: "http://127.0.0.1:3000/public/Trust in government’s social media service and citizen’s patronage behavior.txt", title: "Computer secuitry", author: "stev hension", score: value.score }
        }


    });
    res.json(result_term)













    var searchTerm = req.params.qtext;
    q_array = searchTerm.split(' ');


    if (q_array.length >= 1)

    {

        if (q_array[1] == "or") {



            stopword_token(searchTerm, function(data) {


                index.addDoc(doc1);
                index.addDoc(doc2);
                index.addDoc(doc3);
                index.addDoc(doc4);
                index.addDoc(doc5);
                index.addDoc(doc6);
                index.addDoc(doc7);


                ress = index.search(q_array[0], {
                    fields: {

                        body: { boost: 2 }
                    },
                    bool: "OR"
                });
                res.json({ "ans": ress })
                res.end();
                exit();

            })



        }
    }
    if (q_array[1] == "and") {


        stopword_token(searchTerm, function(data) {
            var doc1 = {
                "id": 1,
                "title": "Information system",
                "body": doc_1
            }

            var doc2 = {
                "id": 2,
                "title": "Computer interaction",
                "body": doc_2
            }
            var doc3 = {
                "id": 3,
                "title": "Computer secuirty",
                "body": doc_3
            }
            var doc4 = {
                "id": 4,
                "title": "Computer application using nodejs",
                "body": doc_4
            }
            var doc5 = {
                "id": 5,
                "title": "human computer interaction",
                "body": doc_5
            }
            var doc6 = {
                "id": 6,
                "title": "nodejs in large scale application",
                "body": doc_6
            }

            var doc7 = {
                "id": 7,
                "title": "trust in e govt",
                "body": doc_7
            }
            index.addDoc(doc1);
            index.addDoc(doc2);
            index.addDoc(doc3);
            index.addDoc(doc4);
            index.addDoc(doc5);
            index.addDoc(doc6);
            index.addDoc(doc7);
            elasticlunr.clearStopWords();
            ress = index.search(req.params.qtext)
            result_term = []
            _.forEach(ress, function(value, key) {

                if (key == 0) {
                    result_term[0] = { url: "http://127.0.0.1:3000/public/node-dev.txt", title: "Information system", author: "adil", score: value.score }
                }
                if (key == 1) {
                    result_term[1] = { url: "http://127.0.0.1:3000/public/node-dev.txt/node-dev1.txt", title: "computer interaction", author: "Ali", score: value.score }
                }
                if (key == 3) {
                    result_term[3] = { url: "http://127.0.0.1:3000/public/Trust in government’s social media service and citizen’s patronage behavior.txt", title: "E govt", author: "Ali", score: value.score }
                }
                if (key == 4) {
                    result_term[4] = { url: "http://127.0.0.1:3000/public/Trust in government’s social media service and citizen’s patronage behavior.txt", title: "Computer secuitry", author: "stev hension", score: value.score }
                }


            });
            res.json(result_term)

        })



    }



    // stopword_token(searchTerm, function(data) {
    //     ress = index.search(req.params.qtext)
    //     result_term = []
    //     _.forEach(ress, function(value, key) {

    //         if (key == 0) {
    //             result_term[0] = { url: "http://127.0.0.1:3000/public/node-dev.txt", title: "Information system", author: "Jcob ", score: value.score }
    //         }
    //         if (key == 1) {
    //             result_term[1] = { url: "http://127.0.0.1:3000/public/node-dev.txt/node-dev1.txt", title: "computer interaction", author: "Ali", score: value.score }
    //         }
    //         // if (key == 3) {
    //         //     result_term[3] = { url: "http://127.0.0.1:3000/public/Trust in government’s social media service and citizen’s patronage behavior.txt", title: "E govt", author: "Ali", score: value.score }
    //         // }
    //         // if (key == 4) {
    //         //     result_term[4] = { url: "http://127.0.0.1:3000/public/Trust in government’s social media service and citizen’s patronage behavior.txt", title: "Computer secuitry", author: "stev hension", score: value.score }
    //         // }

    //     });
    //     res.json(result_term)
    //     console.log(result_term);

    // })
});



app.use('/inverted_index', function(req, res) {

    res.json({ hi: "hi" })

});

// catch 404 and forward to error handler
app.use(function(req, res, next) {
    var err = new Error('Not Found');
    err.status = 404;
    next(err);
});






// stop word removal section
var nlp = require('nlp-toolkit');
var fs = require('fs');
var es = require('event-stream');
var data = '';
// get an array of english stopwords
require('stopwords').english;

var stopwords = require('stopwords').english;
var natural = require('natural');
sw = require('stopword')
var natural = require('natural'),
    stemmer = natural.PorterStemmer;

//conver_doc('./public/researh_paper/node-dev1.txt')




// var dir = require('node-dir');

// console.log(__dirname)
// dir.readFiles(__dirname + '/public/', {
//         match: /.txt$/,
//         exclude: /^\./
//     }, function(err, content, next) {
//         if (err) throw err;
//         //console.log('content:', content);
//         // process.exit()
//     },
//     function(err, files) {
//         if (err) throw err;
//         console.log('finished reading files:', files);
//     });

// conver_doc('./public/ck-10-problems.txt')
// conver_doc('./public/doc2.txt')
// conver_doc('./public/computer-secuirty-in-real-word.txt')
// conver_doc('./public/Trust in government’s social media service and citizen’s patronage behavior.txt')
// conver_doc('./public/doc3.txt')
// conver_doc('./public/using nodejs to build application.txt')
// conver_doc('./public/writingResearchPapers.txt')



//method section
//document conversion section
function conver_doc(file_url) {
    var readStream = fs.createReadStream(file_url, 'utf8');
    readStream.on('data', function(chunk) {
        data += chunk;
    }).on('end', function() {

        var stopwords = require('stopwords').english;
        var natural = require('natural');

        var stemmedAndNoStopwords =
            data.split(/\W+/)
            // stopwords filtering
            .filter((w) => {
                return stopwords.indexOf(w.toLowerCase()) < 0
            })
            // stemming
            .map((word) => {


                return natural.PorterStemmer.stem(word)
            })
            .join(" ")

        console.log("STEM", stemmedAndNoStopwords)
            //  include the Keyword Extractor 
        var keyword_extractor = require("keyword-extractor");


        var extraction_result = keyword_extractor.extract(stemmedAndNoStopwords, {
            language: "english",
            remove_digits: true,
            return_changed_case: true,
            remove_duplicates: true

        });

        console.log("KEY WORD", extraction_result)
        var string_val = extraction_result.join();

        var formattedString = string_val.split(",").join(" ")
        var parts = file_url.split('/');
        var lastSegment = parts.pop() || parts.pop(); // handle potential trailing slash
        fs.writeFile(lastSegment + '.json', extraction_result, (err) => {
            // throws an error, you could also catch it here
            if (err) {


            } else {
                console.log(extraction_result)

            }

            // success case, the file was saved
            // console.log('Lyric saved!');

        });


        // const oldString = data.split(' ');
        // console.log(oldString)
        // const newString = sw.removeStopwords(oldString)
        // console.log(newString);
    });
}


//query term cleaner section 
function stopword_token(qterm, text) {

    var stopwords = require('stopwords').english;
    var natural = require('natural');


    //  include the Keyword Extractor 
    var keyword_extractor = require("keyword-extractor");


    var extraction_result = keyword_extractor.extract(qterm, {
        language: "english",
        remove_digits: true,
        return_changed_case: true,
        remove_duplicates: true

    });

    console.log(extraction_result)
    var string_val = extraction_result.join();

    var formattedString = string_val.split(",").join(" ")
    console.log("resut is")
    console.log(formattedString)
    text(formattedString)

}













// error handler
app.use(function(err, req, res, next) {
    // set locals, only providing error in development
    res.locals.message = err.message;
    res.locals.error = req.app.get('env') === 'development' ? err : {};

    // render the error page
    res.status(err.status || 500);
    res.render('error');
});

module.exports = app;